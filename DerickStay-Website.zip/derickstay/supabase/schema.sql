-- Run this entire file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text check (char_length(display_name) <= 60),
  bio text not null default '' check (array_length(regexp_split_to_array(trim(bio), '\s+'), 1) <= 177 or trim(bio) = ''),
  avatar_url text,
  created_at timestamptz not null default now()
);
create table if not exists public.properties (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) <= 100),
  property_type text not null check (property_type in ('House','Apartment','Room')),
  location text not null,
  monthly_rent numeric(12,2) not null check (monthly_rent >= 0),
  description text not null check (char_length(description) <= 1500),
  photo_urls text[] not null default '{}',
  status text not null default 'published' check (status in ('published','draft','hidden')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint max_seven_photos check (cardinality(photo_urls) <= 7)
);
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  type text not null check (type in ('profile_view','listing_view')),
  message text not null,
  entity_id uuid,
  is_read boolean not null default false,
  created_at timestamptz not null default now(),
  constraint no_self_notification check (actor_id is null or actor_id <> recipient_id)
);
alter table public.profiles enable row level security;
alter table public.properties enable row level security;
alter table public.notifications enable row level security;

drop policy if exists "Profiles are viewable by everyone" on public.profiles;
create policy "Profiles are viewable by everyone" on public.profiles for select using (true);
drop policy if exists "Users insert own profile" on public.profiles;
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Published properties are public" on public.properties;
create policy "Published properties are public" on public.properties for select using (status = 'published' or auth.uid() = owner_id);
drop policy if exists "Owners create properties" on public.properties;
create policy "Owners create properties" on public.properties for insert to authenticated with check (auth.uid() = owner_id);
drop policy if exists "Owners update properties" on public.properties;
create policy "Owners update properties" on public.properties for update to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
drop policy if exists "Owners delete properties" on public.properties;
create policy "Owners delete properties" on public.properties for delete to authenticated using (auth.uid() = owner_id);

drop policy if exists "Users read own notifications" on public.notifications;
create policy "Users read own notifications" on public.notifications for select to authenticated using (auth.uid() = recipient_id);
drop policy if exists "Signed in users create view notifications" on public.notifications;
create policy "Signed in users create view notifications" on public.notifications for insert to authenticated with check (auth.uid() = actor_id and auth.uid() <> recipient_id);

-- Storage buckets (public read, authenticated owner-only uploads).
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('property-photos','property-photos',true,8388608,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('avatars','avatars',true,8388608,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "Public can view property photos" on storage.objects;
create policy "Public can view property photos" on storage.objects for select using (bucket_id in ('property-photos','avatars'));
drop policy if exists "Owners upload property photos" on storage.objects;
create policy "Owners upload property photos" on storage.objects for insert to authenticated with check (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Owners update property photos" on storage.objects;
create policy "Owners update property photos" on storage.objects for update to authenticated using (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text) with check (bucket_id = 'property-photos' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Owners upload avatars" on storage.objects;
create policy "Owners upload avatars" on storage.objects for insert to authenticated with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Owners update avatars" on storage.objects;
create policy "Owners update avatars" on storage.objects for update to authenticated using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text) with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- Create a profile row automatically when an account is created.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,email) values(new.id,new.email)
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Realtime notifications can be enabled in Database > Replication if desired.
